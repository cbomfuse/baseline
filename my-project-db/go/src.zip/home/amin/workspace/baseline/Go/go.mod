module example.com/cbom-corpus

go 1.26.0

require (
	github.com/cloudflare/circl v1.6.5
	golang.org/x/crypto v0.58.0
)

require golang.org/x/sys v0.49.0 // indirect
